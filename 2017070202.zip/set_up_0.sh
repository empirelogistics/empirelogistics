#!/bin/sh

# 0 - no layers
# 1-1 - rail layer with nothing in the hover
# 1-2 - rail layer with owner and subdivision in the hover

# this script is 0 

cp index/0/index.html /var/www/html/index.html
cp css/0/el.css /var/www/html/css/el.css
cp cfg/0/tiles.cfg /var/www/html/tiles.cfg
./database/0/database.sh

elchanges

