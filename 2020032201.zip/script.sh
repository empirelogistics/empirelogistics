#!/bin/sh

export DEBIAN_FRONTEND=noninteractive
ip=`echo $SSH_CONNECTION | awk 'BEGIN{FS=" "};{print $3}'`

# -----------------------------------------------------------------------------
# these may already have been run by the buildor if they hit a catch-22 situation
# where they couldn't apt install the very first few things to get bootstrapped from.
# If they have already been run, will there be a side effect here?

# edit /etc/gai.conf to prioritize IPv4 when contacting repos
sed -i 's/#precedence\ ::ffff:0:0\/96\ \ 100/precedence\ ::ffff:0:0\/96\ \ 100/' /etc/gai.conf

# edit /etc/wgetrc to prioritize IPv4 when downloading with wget
sed -i 's/#prefer-family \= IPv6/prefer-family = IPv4/' /etc/wgetrc 
# -----------------------------------------------------------------------------

apt -qy update
apt -qy upgrade
apt-get -qy install nginx uwsgi postgresql-9.5-postgis-2.2 libjs-leaflet liblwgeom-2.2.5 unzip uwsgi-plugin-python gawk python-pip fail2ban postgis libjs-jquery libjs-leaflet libjs-d3 libjs-bootstrap psmisc libpq-dev python-dev
mkdir /var/www/html/images
mkdir /var/www/html/css
mkdir /var/www/html/lib
mkdir /var/www/html/data

tar -xvf index.tar
tar -xvf css.tar
tar -xvf cfg.tar
tar -xvf database.tar
grep -rl '\[YOUR IP ADDRESS HERE\]' | xargs sed -i 's/\[YOUR IP ADDRESS HERE\]/'$ip'/g'







cp d3-bootstrap.min.js /var/www/html/lib
#cp icedetentioncenters.png /var/www/html/images
cp jquery.animate-colors-min.js /var/www/html/lib
cp TileLayer.custom_d3_geoJSON.js /var/www/html/lib
cp TileLayer.GeoJSON.js /var/www/html/lib
cp topojson.v1.min.js /var/www/html/lib
cp default /etc/nginx/sites-enabled/default


# let the layer scripts do this
#cp icedetentioncenters.csv /var/www/html/data


cp port_tonnage_2013.csv /var/www/html/data

# let the layer scripts do this
#cp containerroute.sql /var/www/html/data



cp tiles.py /var/www/html/tiles.py
cp tiles.cfg /var/www/html/tiles.cfg
cp uwsgi.ini /var/www/html/uwsgi.ini
service uwsgi stop
cp /usr/share/javascript/leaflet/leaflet.css /var/www/html/css
cp /usr/share/javascript/leaflet/leaflet.js /var/www/html/lib
cp /usr/share/javascript/bootstrap/css/bootstrap.css /var/www/html/css
cp /usr/share/javascript/bootstrap/css/bootstrap-theme.css /var/www/html/css
cp /usr/share/javascript/bootstrap/css/bootstrap.js /var/www/html/lib
cp /usr/share/javascript/bootstrap/js/bootstrap.js /var/www/html/lib
cp /usr/share/javascript/d3/d3.js /var/www/html/lib/d3.js
cp /usr/share/javascript/jquery/jquery.js /var/www/html/lib
cd /var/www/html/lib
wget https://raw.githubusercontent.com/d3/d3-plugins/master/geo/tile/tile.js
wget https://github.com/KoGor/leaflet-fullHash/archive/master.zip
unzip master.zip
cp /var/www/html/lib/leaflet-fullHash-master/leaflet-fullHash.js /var/www/html/lib 
cd /var/www/html
pip install virtualenv
virtualenv myenv
cd myenv/bin
./pip install psycopg2 pillow shapely ModestMaps simplejson werkzeug tilestache mapbox-vector-tile
cd /root
chmod 755 elchanges
cp elchanges /sbin/elchanges

# set up the firewall by script - there is no need to wait for the buildor to do this
cp iptables.firewall.rules /etc/iptables.firewall.rules
iptables-restore < /etc/iptables.firewall.rules
cp firewall /etc/network/if-pre-up.d/firewall
chmod +x /etc/network/if-pre-up.d/firewall
