#!/bin/sh
cd /var/www/html/data
test -s qc48R.zip || wget http://cta.ornl.gov/transnet/qc48R.zip
test -s qc48V.zip || wget http://cta.ornl.gov/transnet/qc48V.zip
test -s wconv.txt || wget http://cta.ornl.gov/transnet/wconv.txt
test -s QNdata.zip || wget http://cta.ornl.gov/transnet/QNdata.zip
unzip -n qc48R.zip
unzip -n qc48V.zip
unzip -n QNdata.zip

# the shell code for preparing rail ownership and rail subdivisions
# happens up here, before the db code happens all as a bundle

cd /var/www/html/data
cat wconv.txt | cut -c1-15 --complement | gawk --re-interval 'BEGIN{FS=" {2,}"};{ print $1 }' > rail_long.txt
cat wconv.txt | cut -c8-11 > rail_short.txt
cat rail_short.txt | tr -d [:blank:] > rail_short_trimmed.txt
paste rail_short_trimmed.txt rail_long.txt -d'|' > rail_ownership.csv
sed 's/\r//g' rail_ownership.csv | tail -n+42 > rail_ownership2.csv

####

cat subdiv.txt | cut -c8-13 > subdivision_short.txt
cat subdiv.txt | cut -c16-32 > subdivision_long.txt
cat subdivision_short.txt | tr -d [:blank:] > subdivision_short_trimmed.txt
paste subdivision_short_trimmed.txt subdivision_long.txt -d'|' > rail_subdivision.csv
tail -n +6 rail_subdivision.csv > rail_subdivision2.csv
sed 's/\r//g' rail_subdivision2.csv > rail_subdivision3.csv



su postgres <<EOSU
pw=abc123
cd /var/www/html/data
echo 'create database mapdata' | psql -q -U postgres
echo '\\connect mapdata' | psql -q -U postgres
echo 'create user mapdbuser' | psql -q -U postgres -d mapdata
echo 'create extension postgis' | psql -q -U postgres -d mapdata
echo 'drop table rail' | psql -q -U postgres -d mapdata
shp2pgsql -s 4326:900913 -t 2d -I qc48l rail | psql -q -U postgres -d mapdata
echo 'GRANT all privileges on rail to mapdbuser' | psql -q -U postgres -d mapdata
echo "alter role mapdbuser PASSWORD '\$pw'" | psql -q -U postgres -d mapdata
echo "create table rail_ownership(w1 text,longdesc text)" | psql -q -U postgres -d mapdata
echo "create table rail_subdivision(sb text,longdesc text)" | psql -q -U postgres -d mapdata
echo "\COPY rail_ownership FROM '/var/www/html/data/rail_ownership2.csv' DELIMITER '|' CSV" | psql -q -U postgres -d mapdata
echo "\COPY rail_subdivision FROM '/var/www/html/data/rail_subdivision3.csv' DELIMITER '|' CSV" | psql -q -U postgres -d mapdata
echo 'GRANT all privileges on rail_ownership to mapdbuser' | psql -q -U postgres -d mapdata
echo 'GRANT all privileges on rail_subdivision to mapdbuser' | psql -q -U postgres -d mapdata
EOSU
# i need a copy statement for subdivisions
# interactive steps (not scripted)
# go into psql
# select from the rail table and identify what fields correspond to a unique ID, label or title for that item, the geometry, and additional name-value pairs that will be useful to see on hover
# finalize the SQL statement that selects these things and set it aside

# create a layer in tiles.cfg using your newly created SQL query




cd /root













