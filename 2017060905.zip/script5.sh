#!/bin/sh

# 0 - no layers
# 1-1 - rail layer with nothing in the hover
# 1-2 - rail layer with owner and subdivision in the hover

# this script is 1-2



cp index/1/2/index.html /var/www/html/index.html
cp css/1/el.css /var/www/html/css/el.css
cp cfg/1/2/tiles.cfg /var/www/html/tiles.cfg
elchanges

