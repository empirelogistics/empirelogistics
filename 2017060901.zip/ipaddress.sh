#!/bin/sh

ip=`echo $SSH_CONNECTION | awk 'BEGIN{FS=" "};{print $3}'`
grep -rl '\[YOUR IP ADDRESS HERE\]' | xargs sed -i 's/\[YOUR IP ADDRESS HERE\]/'$ip'/g'

