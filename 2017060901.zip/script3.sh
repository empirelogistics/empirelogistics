#!/bin/sh
cd /var/www/html/data
test -s qc48R.zip || wget http://cta.ornl.gov/transnet/qc48R.zip
test -s qc48V.zip || wget http://cta.ornl.gov/transnet/qc48V.zip
test -s wconv.txt || wget http://cta.ornl.gov/transnet/wconv.txt
unzip -n qc48R.zip
unzip -n qc48V.zip

su postgres <<EOSU
pw=abc123
cd /var/www/html/data
echo 'create database mapdata' | psql -q -U postgres
echo '\\connect mapdata' | psql -q -U postgres
echo 'create user mapdbuser' | psql -q -U postgres -d mapdata
echo 'create extension postgis' | psql -q -U postgres -d mapdata
echo 'drop table rail' | psql -q -U postgres -d mapdata
shp2pgsql -s 4326:900913 -t 2d -I qc48l rail | psql -q -U postgres -d mapdata
echo 'GRANT all privileges on rail to mapdbuser' | psql -q -U postgres -d mapdata
echo "alter role mapdbuser PASSWORD '\$pw'" | psql -q -U postgres -d mapdata
EOSU

# interactive steps (not scripted)
# go into psql
# select from the rail table and identify what fields correspond to a unique ID, label or title for that item, the geometry, and additional name-value pairs that will be useful to see on hover
# finalize the SQL statement that selects these things and set it aside

# create a layer in tiles.cfg using your newly created SQL query


















