#!/bin/sh

  138  cat wconv.txt | cut -c1-15 --complement | gawk --re-interval 'BEGIN{FS=" {2,}"};{ print $1 }' > rail_long.txt
  139  cat wconv.txt | cut -c8-11 > rail_short.txt
  140  cat rail_short.txt | tr -d [:blank:] > rail_short_trimmed.txt
  141  sed 's/\r//g' rail_ownership.csv > rail_ownership2.csv
  142  paste rail_short_trimmed.txt rail_long.txt -d'|' > rail_ownership.csv
  143  sed 's/\r//g' rail_ownership.csv > rail_ownership2.csv
  144  vi rail_ownership2.csv
  145  su - postgres
  146  \COPY rail_ownership FROM '/var/www/html/data/rail_ownership2.csv' DELIMITER '|' CSV;
  216  cat subdiv.txt
  217  cat subdiv.txt | more
  218  cat subdiv.txt | cut -c1-13
  219  cat subdiv.txt | cut -c8-13
  220  cat subdiv.txt | cut -c8-13 | more
  221  cat subdiv.txt | cut -c8-14 | more
  222  cat subdiv.txt | cut -c8-13 --complement | more
  223  cat subdiv.txt | cut -c8-13
  224  cat subdiv.txt | cut -c8-13 | more
  225  cat subdiv.txt | cut -c8-14 | more
  226  cat subdiv.txt | cut -c8-13 > subdivision_short
  227  cat subdiv.txt
  228  cat subdiv.txt | more
  229  cat subdiv.txt | cut -c16-32
  230  cat subdiv.txt | cut -c16-32 | more
  231  cat subdiv.txt | cut -c16-33 | more
  232  cat subdiv.txt | cut -c16-33 > subdivision_long
  233  paste subdivision_short subdivision_long -d'|' > rail_subdivision.csv
  234  more rail_subdivision.csv
  235  cat subdiv.txt | cut -c16-32 > subdivision_long
  236  paste subdivision_short subdivision_long -d'|' > rail_subdivision.csv
  237  more rail_subdivision.csv
  238  man head
  239  man tail
  240  tail -n +2 rail_subdivisions.csv
  241  tail -n +2 rail_subdivision.csv
  242  tail -n +2 rail_subdivision.csv | more
  243  tail -n +3 rail_subdivision.csv | more
  244  tail -n +4 rail_subdivision.csv | more
  245  tail -n +3 rail_subdivision.csv | more
  246  ls
  247  vi subdiv.txt
  248  tail -n +6 rail_subdivision.csv | more
  249  tail -n +6 rail_subdivision.csv > rail_subdivision2.csv
  250  vi rail_subdivision2.csv
  251  su - postgres
  252  vi rail_subdivision2.csv
  253  sed 's/\r//g' rail_subdivision2.csv > rail_subdivision3.csv
  254  su - postgres
  255  ls
  256  more subdivision_short
  257  cat subdivision_short.txt | tr -d [:blank:] > subdivision_short_trimmed.txt
  258  cat subdivision_short | tr -d [:blank:] > subdivision_short_trimmed.txt
  259  ls
  260  rm rail_subdivision.csv
  261  rm rail_subdivision2.csv
  262  rm rail_subdivision3.csv
  263  paste subdivision_short_trimmed.txt subdivision_long -d'|' > rail_subdivision.csv
  264  tail -n +6 rail_subdivision.csv > rail_subdivision2.csv
  265  sed 's/\r//g' rail_subdivision2.csv > rail_subdivision3.csv
