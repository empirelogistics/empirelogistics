#!/bin/sh

cd /root
tar -xvf index.tar
tar -xvf css.tar
tar -xvf cfg.tar
cp index/1/index.html /var/www/html/index.html
cp css/1/el.css /var/www/html/css/el.css
cp cfg/1/1/tiles.cfg /var/www/html/tiles.cfg

