#!/bin/sh

do this
do that
wget
wget
wget
mv
mv
mv
