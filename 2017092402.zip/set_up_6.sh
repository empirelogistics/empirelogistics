#!/bin/sh

./database/6/database.sh
cp index/6/index.html /var/www/html/index.html
cp css/6/el.css /var/www/html/css/el.css
cp cfg/6/tiles.cfg /var/www/html/tiles.cfg

elchanges

