#!/bin/sh

cd /var/www/html/data

su postgres <<EOSU
echo 'drop database mapdata' | psql -q -U postgres
EOSU


zipinfo -1 tl_2016_us_aiannh.zip | xargs rm
zipinfo -1 CrudeOil_Pipelines_US_EIA.zip | xargs rm
zipinfo -1 qc48R.zip | xargs rm
zipinfo -1 qc48V.zip | xargs rm
zipinfo -1 QNdata.zip | xargs rm
zipinfo -1 WPI_Shapefile.zip | xargs rm
rm CrudeOil_Pipelines_US_EIA.zip
rm qc48R.zip
rm qc48V.zip
rm QNdata.zip
rm tl_2016_us_aiannh.zip
rm WPI_Shapefile.zip
rm rail_long.txt
rm rail_short.txt
rm rail_short_trimmed.txt
rm rail_ownership.csv
rm rail_ownership2.csv
rm subdivision_short.txt
rm subdivision_long.txt
rm subdivision_short_trimmed.txt
rm rail_subdivision.csv
rm rail_subdivision2.csv
rm rail_subdivision3.csv
rm wconv.txt
rm icedetentioncenters.csv
rm containerroute.sql
cd /root


cp index/0/index.html /var/www/html/index.html
cp css/0/el.css /var/www/html/css/el.css
cp cfg/0/tiles.cfg /var/www/html/tiles.cfg
./database/0/database.sh

elchanges

