#!/bin/sh

./database/4/database.sh
cp index/4/index.html /var/www/html/index.html
cp css/4/el.css /var/www/html/css/el.css
cp cfg/4/tiles.cfg /var/www/html/tiles.cfg

elchanges

