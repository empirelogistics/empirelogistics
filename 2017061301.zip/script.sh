#!/bin/sh

# change the precedence so that contacting repositories will not be held up by IPv6
sed -i 's/\#precedence ::ffff:0:0\/96  100/precedence ::ffff:0:0\/96  100/' /etc/gai.conf

export DEBIAN_FRONTEND=noninteractive
ip=`echo $SSH_CONNECTION | awk 'BEGIN{FS=" "};{print $3}'`


apt -qy update
apt -qy upgrade
apt-get -qy install nginx uwsgi postgresql-9.5-postgis-2.2 libjs-leaflet liblwgeom-2.2.5 unzip uwsgi-plugin-python gawk python-pip fail2ban postgis libjs-jquery libjs-leaflet libjs-d3 libjs-bootstrap
mkdir /var/www/html/images
mkdir /var/www/html/css
mkdir /var/www/html/lib
mkdir /var/www/html/data

tar -xvf index.tar
tar -xvf css.tar
tar -xvf cfg.tar
tar -xvf database.tar
grep -rl '\[YOUR IP ADDRESS HERE\]' | xargs sed -i 's/\[YOUR IP ADDRESS HERE\]/'$ip'/g'







cp d3-bootstrap.min.js /var/www/html/lib
cp icedetentioncenters.png /var/www/html/images
cp jquery.animate-colors-min.js /var/www/html/lib
cp TileLayer.custom_d3_geoJSON.js /var/www/html/lib
cp TileLayer.custom_d3_geoJSON.icons.js /var/www/html/lib
cp TileLayer.GeoJSON.js /var/www/html/lib
cp topojson.v1.min.js /var/www/html/lib
cp default /etc/nginx/sites-enabled/default
cp icedetentioncenters.csv /var/www/html/data
cp port_tonnage_2013.csv /var/www/html/data
cp containerroute.sql /var/www/html/data
cp tiles.py /var/www/html/tiles.py
cp tiles.cfg /var/www/html/tiles.cfg
cp uwsgi.ini /var/www/html/uwsgi.ini
service uwsgi stop
cp /usr/share/javascript/leaflet/leaflet.css /var/www/html/css
cp /usr/share/javascript/leaflet/leaflet.js /var/www/html/lib
cp /usr/share/javascript/bootstrap/css/bootstrap.css /var/www/html/css
cp /usr/share/javascript/bootstrap/css/bootstrap-theme.css /var/www/html/css
cp /usr/share/javascript/bootstrap/css/bootstrap.js /var/www/html/lib
cp /usr/share/javascript/bootstrap/js/bootstrap.js /var/www/html/lib
cp /usr/share/javascript/d3/d3.js /var/www/html/lib/d3.js
cp /usr/share/javascript/jquery/jquery.js /var/www/html/lib
cd /var/www/html/lib
wget https://raw.githubusercontent.com/d3/d3-plugins/master/geo/tile/tile.js
wget https://github.com/KoGor/leaflet-fullHash/archive/master.zip
unzip master.zip
cp /var/www/html/lib/leaflet-fullHash-master/leaflet-fullHash.js /var/www/html/lib 
cd /var/www/html
pip install virtualenv
virtualenv myenv
cd myenv/bin
./pip install psycopg2 pillow shapely ModestMaps simplejson werkzeug tilestache mapbox-vector-tile
cd /root
chmod 755 elchanges
cp elchanges /sbin/elchanges

