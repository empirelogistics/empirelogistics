#!/bin/sh
# caution - rm -rf will delete a folder and everything underneath it
rm -rf /var/www/html/tiles
# caution - rm -rf will delete a folder and everything underneath it
service nginx stop
service postgresql stop
service postgresql start
service nginx start
sleep 1
killall -9 uwsgi
sleep 3
uwsgi /var/www/html/uwsgi.ini &
sleep 3
ps -auxww | grep uwsgi
echo OK
