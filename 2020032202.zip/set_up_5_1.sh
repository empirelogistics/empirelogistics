#!/bin/sh

./database/5/1/database.sh
cp index/5/1/index.html /var/www/html/index.html
cp css/5/1/el.css /var/www/html/css/el.css
cp cfg/5/1/tiles.cfg /var/www/html/tiles.cfg

elchanges

