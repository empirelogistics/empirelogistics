#!/bin/sh

./database/3/database.sh
cp index/3/index.html /var/www/html/index.html
cp css/3/el.css /var/www/html/css/el.css
cp cfg/3/tiles.cfg /var/www/html/tiles.cfg

elchanges

