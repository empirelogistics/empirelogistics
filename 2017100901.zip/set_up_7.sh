#!/bin/sh

./database/7/database.sh
cp index/7/index.html /var/www/html/index.html
cp css/7/el.css /var/www/html/css/el.css
cp cfg/7/tiles.cfg /var/www/html/tiles.cfg

elchanges

