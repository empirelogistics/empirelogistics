#!/bin/sh

# 0 - no layers
# 1-1 - rail layer with nothing in the hover
# 1-2 - rail layer with owner and subdivision in the hover

# this script is 1-2



cp index/1/1/index.html /var/www/html/index.html
cp css/1/1/el.css /var/www/html/css/el.css
cp cfg/1/1/tiles.cfg /var/www/html/tiles.cfg
./database/1/1/database.sh

elchanges

