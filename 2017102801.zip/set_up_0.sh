#!/bin/sh

cp index/0/index.html /var/www/html/index.html
cp css/0/el.css /var/www/html/css/el.css
cp cfg/0/tiles.cfg /var/www/html/tiles.cfg
./database/0/database.sh

elchanges

