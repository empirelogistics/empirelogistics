#!/bin/sh

./database/2/2/database.sh

cp index/2/2/index.html /var/www/html/index.html
cp css/2/2/el.css /var/www/html/css/el.css
cp cfg/2/2/tiles.cfg /var/www/html/tiles.cfg

elchanges

