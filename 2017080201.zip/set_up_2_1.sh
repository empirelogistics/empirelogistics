#!/bin/sh

./database/2/1/database.sh
cp index/2/1/index.html /var/www/html/index.html
cp css/2/1/el.css /var/www/html/css/el.css
cp cfg/2/1/tiles.cfg /var/www/html/tiles.cfg

elchanges

