#!/bin/sh

./database/5/2/database.sh
cp index/5/2/index.html /var/www/html/index.html
cp css/5/2/el.css /var/www/html/css/el.css
cp cfg/5/2/tiles.cfg /var/www/html/tiles.cfg

elchanges

