#!/bin/sh

# 0 - no layers
# 1-1 - rail layer with nothing in the hover
# 1-2 - rail layer with owner and subdivision in the hover

# this script is 1-2



cp index/7/index.html /var/www/html/index.html
cp css/7/el.css /var/www/html/css/el.css
cp cfg/7/tiles.cfg /var/www/html/tiles.cfg
./database/7/database.sh

elchanges

