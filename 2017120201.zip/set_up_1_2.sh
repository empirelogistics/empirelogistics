#!/bin/sh


./database/1/2/database.sh
cp index/1/2/index.html /var/www/html/index.html
cp css/1/2/el.css /var/www/html/css/el.css
cp cfg/1/2/tiles.cfg /var/www/html/tiles.cfg

elchanges

